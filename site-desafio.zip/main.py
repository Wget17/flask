from flask import Flask, request, redirect



app = Flask(__name__, static_folder="files")





@app.route("/", methods=["POST" , "GET"] )
def index():
    if request.method == "POST":

        if request.form["nome"] == "teste" and request.form["senha"] == "teste":

            return redirect("files/bem-vindo.html")
        else:
            return redirect("files/erro.html")
    else:
        return redirect("files/erro.html")

@app.route("/sucesso")
def sucesso():
    return "deu certo"






app.run()